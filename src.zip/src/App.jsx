import React from 'react'
import Login from './pages/Login';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Main from './pages/Main';
import Dashboard from './pages/Dashboard';
import Content from './pages/Content';

const App = () => {
  return (
    <div>
      <BrowserRouter>
      <Routes>
        <Route path="/" element={<Login />}/> {/* 👈 Renders at /app/ */}
        <Route path="/dashboard" element={<Dashboard/>}>
          <Route path="/dashboard/main" element={<Main/>}></Route>
          <Route path="/dashboard/:type/:menu" element={<Content />}></Route>
        </Route>

      </Routes>
    </BrowserRouter>
    </div>
  )
}

export default App
