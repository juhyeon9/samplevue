import { combineReducers } from "redux";
import counter from "./counter";

//기능과 상태 조각을 기반으로 논리를 분할하여 유지관리가 가능하도록 할 수 있음
const rootReducer = combineReducers({
  counter,

})

export default rootReducer;