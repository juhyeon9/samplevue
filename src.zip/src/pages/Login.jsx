import React, {useState} from 'react'
import logo_img from '@/assets/images/admin/login/logo_img.png'
import axios from 'axios'
import { useNavigate } from 'react-router-dom'
//import { Cookies } from 'react-cookie'


const Login = () => {
  const navigate = useNavigate();
  //const cookies = new Cookies();

  const [account, setAccount] = useState({
    userId: '',
    userPw: ''
  })

  //input에 값이 입력될 때마다 Account 상태값 변경하는 함수
  const onChangeAccount = (e) => {
    setAccount({
      ...account,
      [e.target.name]: e.target.value
    })
  }

  //로그인 수행
  const fLoginProc = () => {
    console.log('login start!!')
    console.log(account.userId, account.userPw)

    const params = new URLSearchParams();
    params.append('id', account.userId);
    params.append('pw', account.userPw);

    axios.post('/api/loginProc', params)
    .then(function (res) {
      console.log(res);
      const data = res.data
      if(data.resCode==="success") {
        alert('로그인 성공')
        sessionStorage.setItem('loginId', data.loginId)
        sessionStorage.setItem('userNm', data.userNm)
        sessionStorage.setItem('usrMnuAtrt', JSON.stringify(data.usrMnuAtrt))


        //메인페이지 이동
        navigate("/dashboard/main");

      } else {
        alert('로그인 실패')
      }

    })
    .catch(function (error) {
      console.log(error);
    });
  }

  const onKeyUpAccount = (e) => {
    console.log(e.keyCode)
    if(e.keyCode===13) fLoginProc();
  }

  return (
    <div id='background_board'>
      <div className='login_form shadow'>
        <div className='login-form-right-side'>
          <div className='top-logo-wrap'>
            <img id='login-logo' src={logo_img}  alt = "logo"/>
          </div>
          <h3> 안되는 것이 실패가 아니라 포기하는 것이 실패다 </h3>
          <p>
            성공은 실패의 꼬리를 물고 온다.지금 포기한 것이 있는가 ?
            <br />
            그렇다면 다시 시작해 보자. <br />
            안되는 것이 실패가 아니라 포기하는 것이 실패다. <br />
            포기한 순간이 성공하기 5 분전이기 쉽다. <br />
            실패에서 더 많이 배운다. <br />
            실패를 반복해서 경험하면 실망하기 쉽다. <br />
            하지만 포기를 생각해선 안된다.실패는 언제나 중간역이지 종착역은
            아니다. <br />
          </p>
          <p> -이대희, ‘1 % 의 가능성을 희망으로 바꾼 사람들’ 에서 </p>
        </div>
        <div className='login-form-left-side'>
          <fieldset>
            <p className='id'>
              <label htmlFor='userId'> 아이디 </label>
              <input
                id='userId'
                type='text'
                name='userId'
                placeholder='아이디'
                onChange={onChangeAccount}
              />
            </p>
            <p className='pw'>
              <label htmlFor='userPw'> 비밀번호 </label>
              <input
                id='userPw'
                type='password'
                name='userPw'
                placeholder='비밀번호'
                onChange={onChangeAccount}
                onKeyUp={onKeyUpAccount}
             />
            </p>
            <p className='member_info'>
              <input id='saveId' type='checkbox' />
              <span className='id_save'> ID저장 </span>
            </p>
            <div>
              <a href='#!' id='RegisterBtn'>
                <strong> [회원가입] </strong>
              </a>
              <a href='#!' >
                <strong> [아이디 / 비밀번호 찾기] </strong>
              </a>
            </div>
            <a href='#!' className='btn_login' id='btn_login' onClick={fLoginProc}>
              <strong> Login </strong>
            </a>
          </fieldset>
        </div>
      </div>
    </div>
  )
}

export default Login
