import React from 'react'
import { useParams } from 'react-router-dom'
import ErrorBoundary from '../components/common/ErrorBoundary';

function toCaptitalize(str) {
  return str.replace(/\b\w/g, (match) => match.toUpperCase());
}

const Content = () => {
  const params = useParams();
  console.log('params:::' + JSON.stringify(params));
  const Page = React.lazy(() => import('./' + params.type + '/' 
                                  + toCaptitalize(params.menu) + '.jsx'));
  return (
    <div>
      <ErrorBoundary>
        <React.Suspense fallback={<div>Loading...</div>}>
          <Page />
        </React.Suspense>
      </ErrorBoundary>
    </div>
  )
}

export default Content
