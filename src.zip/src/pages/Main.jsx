import React from 'react'

const Main = () => {
  return (
    <div>
      메인페이지입니다.
    </div>
  )
}

export default Main
