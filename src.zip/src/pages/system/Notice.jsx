import React from 'react'
import { useState, useEffect } from 'react'
import axios from 'axios';
import Pagination from '../../components/common/Pagination';
import NoticeDetailModal from '../../components/system/NoticeDetailModal';

const Notice = () => {
  let today = new Date();
  today = today.toISOString().slice(0, 10);
  //검색조건
  const [searchKey, setSearchKey] = useState('');
  const [keyword, setKeyword] = useState('');
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState(today);

  //검색결과
  const [totalCount, setTotalCount] = useState(0);
  const [noticeList, setNoticeList] = useState([]);

  //페이징 관련
  const blockSize = 5;
  const pageSize = 5;
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPage, setTotalPage] = useState(0);

  //공지사항 상세 관련
  //action : 신규(N), 상세(U)
  //show : 상세모달 보일지 안보일지 boolean값
  //noticeNo: 공지상세 공지번호
  const [action, setAction]= useState('');
  const [show, setShow] = useState(false);
  const [noticeNo, setNoticeNo] = useState('');

  //검색 호출
  const searchList = (cPage) => {
    cPage = cPage || 1;
    let params = new URLSearchParams();
    params.append('option', searchKey);
    params.append('keyword', keyword);
    params.append('fromDate', fromDate);
    params.append('toDate', toDate);
    params.append('pageSize', pageSize);
    params.append('currentPage', cPage);

    axios.post('/api/system/noticeList.do', params)
    .then((res)=>{
      console.log('response start!!');
      console.log(res);
      setNoticeList(res.data.noticeList);
      setTotalCount(res.data.noticeCnt);
      setTotalPage(Math.ceil(res.data.noticeCnt / pageSize)); //총페이지
      setCurrentPage(cPage);
    })
    .catch(err=> {
      console.log(err);
    })


  }

  //로드시 조회
  useEffect(()=>{
    searchList(1);
  }, [])

  //신규등록
  const newReg = () => {
    console.log('신규등록!')
    setShow(true);
    setAction('N');
    setNoticeNo('');
  }

  //공지상세
  const searchDetail= (no) => {
    console.log(no)
    console.log('공지상세!')
    setShow(true);
    setAction('U');
    setNoticeNo(no);
  }
  
  return (
    <div id="notice">
    <p className="Location">
      <a href="/dashboard/main" className="btn_set home">home</a>
      <span className="btn_nav bold">시스템관리</span>
      <span className="btn_nav bold">공지사항 관리</span>
      <a href="../system/notice" className="btn_set refresh">새로고침</a>
    </p>
    <p className="conTitle">
      <span>공지사항</span>
    </p>
    <span>
      <table
        style={{border: '1px #50bcdf'}}
        width="100%"
        cellPadding="5"
        cellSpacing="0"
        border="1"
        align="left"
      >
        <tbody>
          <tr style={{border: '0px', borderColor: 'blue'}}>
            <td
              width="50"
              height="25"
              style={{fontSize: '100%', textAlign: 'left'}}
            >
              <div id="searchArea" className="d-flex justify-content-around mb-2 mt-2">
                <select
                  id="searchKey"
                  className="form-select"
                  style={{width: '100px', height: '38px'}}
                  onChange={(e) => {
                    setSearchKey(e.target.value)
                  }}
                >
                  <option value="all">전체</option>
                  <option value="title">제목</option>
                  <option value="content">내용</option>
                </select>

                <input
                  type="text"
                  style={{width: '200px'}}
                  className="form-control"
                  onChange={(e) => {
                    setKeyword(e.target.value)
                  }}
                />
                <input
                  type="date"
                  style={{width: '15%'}}
                  className="form-control"
                  onChange={(e) => {
                    setFromDate(e.target.value)
                  }}
                />
                ~ 
                <input
                  type="date"
                  style={{width: '15%'}}
                  className="form-control"
                  value={toDate}
                  onChange={(e) => {
                    setToDate(e.target.value)
                  }}
                />
                <span className="fr">
                  <button
                    className="btn btn-primary mx-2"
                    id="btnSearchNotice"
                    name="btn"
                    onClick={()=>searchList(1)}
                  >
                    <span>검 색</span>
                  </button>
                  <button
                    className="btn btn-primary"
                    onClick={newReg}
                  >
                    <span>신규등록</span>
                  </button>
                </span>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </span>
    <div className="divComGrpCodList">
      <span><br/><br/><br/>
        총 게시글: {totalCount} / 현재 페이지 번호 : {currentPage}
      </span>
      <table className="col">
        <colgroup>
          <col width="15px" />
          <col width="80px" />
          <col />
          <col width="100px" />
          <col width="100px" />
          <col width="100px" />
        </colgroup>

        <thead>
          <tr>
            <th>
              <input
                type='checkbox'
                name='noticeAllCheck'
              />
            </th>
            <th scope="col">공지번호</th>
            <th scope="col">제목</th>
            <th scope="col">등록일자</th>
            <th scope="col">등록자ID</th>
            <th scope="col">등록자명</th>
          </tr>
        </thead>
        <tbody>
          {noticeList.map((item, index) =>{
            return(
              <tr key={index}>
                <td>
                  <input
                    type='checkbox'
                  />
                </td>
                <td>{item.notice_no}</td>
                <td style={{cursor: 'pointer'}} onClick={()=>searchDetail(item.notice_no)}>{item.notice_title}</td>
                <td>{item.notice_regdate}</td> 
				        <td>{item.login_id}</td>
                <td>{item.user_name}</td>
              </tr>
            )
          })}
        </tbody>
      </table>
      {/* 페이징 처리 */}
      <Pagination 
        currentPage={currentPage}
        totalPage={totalPage}
        blockSize={blockSize}
        onClick={searchList}
      />
    </div>
    <NoticeDetailModal 
      show={show}
      setShow={setShow}
      action={action}
      noticeNo={noticeNo}
    />
  </div>
  )
}

export default Notice
