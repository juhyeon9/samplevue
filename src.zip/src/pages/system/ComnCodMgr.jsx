import React from 'react'
import axios from 'axios'
import { useState, useEffect } from 'react'
import Pagination from '../../components/common/Pagination'
import GroupDetailModal from '../../components/system/GroupDetailModal'
import DetailCodeModal from '../../components/system/DetailCodeModal'


const ComnCodMgr = () => {
  
  //검색조건
  const [searchKey, setSearchKey] = useState('')
  const [searchword, setSearchword] = useState('')
  const [useyn, setUseyn] = useState('')

  //검색결과
  const [groupList, setGroupList] = useState([]);
  const [totalCount, setTotalCount] = useState(0)
  const [dcodeList, setDcodeList] = useState([])
  const [dtotalCount, setDtotalCount] = useState(0)

  //페이징
  const blockSize=5
  const pageSize=5
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPage, setTotalPage] = useState(0)
  const [dcurrentPage, setDcurrentPage] = useState(1)
  const [dtotalPage, setDtotalPage] = useState(0)

  //그룹코드
  const [groupCode, setGroupCode] = useState('')
  const [action, setAction]= useState('');
  const [show, setShow] = useState(false);
  const [dshow, setDshow] = useState(false);
  const [detailCode, setDetailCode] = useState('')
  

  //로드시 그룹코드 조회
  useEffect(()=>{
    searchGroupList();
  }, [])
  
  //그룹코드 조회
  const searchGroupList = (cPage) => {
    cPage = cPage || 1

    const params = new URLSearchParams()
    params.append('searchKey', searchKey)
    params.append('searchWord', searchword)
    params.append('useyn', useyn)
    params.append('cpage', cPage)
    params.append('pageSize', pageSize)

    axios.post('/api/system/listGroupCode.do', params)
      .then(res=>{
        console.log(res)
        setGroupList(res.data.groupList)  //그룹코드리스트
        setTotalCount(res.data.totalcnt) //총갯수
        setTotalPage(Math.ceil(res.data.totalcnt/pageSize)) //총페이지
        setCurrentPage(cPage)
      })
      .catch(err=>{
        console.log(err);
      })
  }

  //상세코드리스트 조회
  const detailCodeList = (dcPage, gCode)=> {
    dcPage = dcPage || 1

    const params = new URLSearchParams()
    params.append('groupCode', gCode)
    params.append('cpage', dcPage)
    params.append('pageSize', pageSize)
    axios.post('/api/system/listDetailCode.do', params)
      .then(res=>{
        console.log(res)
        setDcodeList(res.data.detailCodeList)  //상세코드리스트
        setDtotalCount(res.data.totalcnt) //총갯수
        setDtotalPage(Math.ceil(res.data.totalcnt/pageSize)) //총페이지
        setDcurrentPage(dcPage)
        setGroupCode(gCode)
      })
      .catch(err=>{
        console.log(err);
      })
  }

  //신규그룹등록
  const newGroupReg = () => {
    console.log('신규그룹등록!')
    setShow(true);
    setAction('I');
    setGroupCode('');
  }

  //그룹코드상세
  const searchGroupDetail= (gCode) => {
    console.log(gCode)
    console.log('그룹코드상세!')
    setShow(true);
    setAction('U');
    setGroupCode(gCode);
  }


  //신규상세코드등록
  const newDCodeReg = () => {
    console.log('신규상세코드등록!')
    if(!groupCode) return;
    setDshow(true);
    setAction('I');
    setDetailCode('');
  }

  //상세코드상세
  const searchDetailCode= (dCode) => {
    console.log('상세코드상세!')
    if(!groupCode) return;
    console.log(dCode)
    setDshow(true);
    setAction('U');
    setDetailCode(dCode)
  }
  return (
    <div>
      <p className="Location">
        <a href="/dashboard/main" className="btn_set home">home</a>
        <span className="btn_nav bold">시스템관리</span>
        <span className="btn_nav bold">공통코드 관리</span>
        <a href="../system/comnCodMgr" className="btn_set refresh">새로고침</a>
      </p>
      <p class='conTitle'>
        <span> 공통 코드 관리 </span>
      </p>
      <span>
        <table
          style={{border: '1px #50bcdf'}}
          width="100%"
          cellPadding="5"
          cellSpacing="0"
          border="1"
          align="left"
        >
        <tbody>
          <tr style={{border: '0px', borderColor: 'blue'}}>
            <td
              width="50"
              height="25"
              style={{fontSize: '100%', textAlign: 'left'}}
            >
              <div id="searchArea" className="d-flex justify-content-around mb-2 mt-2">
                <select
                  id='searchKey'
                  name='searchKey'
                  onChange={(e)=>setSearchKey(e.target.value)}
                >
                  <option value=''>전체</option>
                  <option value='code'>코드</option>
                  <option value='name'>코드명</option>
                </select>
                <input
                  type='text'
                  style={{width: '200px', height: '30px'}}
                  className='form-control'
                  id='searchword'
                  name='searchword'
                  onChange={(e)=>setSearchword(e.target.value)}
                />
                사용 여부
                <select
                  id='useyn'
                  name='useyn'
                  onChange={(e)=>setUseyn(e.target.value)}
                >
                  <option value=''>전체</option>
                  <option value='Y'>사용</option>
                  <option value='N'>미사용</option>
                </select>
                <span className="fr">
                  <button
                    className="btn btn-primary mx-2"
                    id="btnSearchGrpcod"
                    name="btn"
                    onClick={()=>searchGroupList(1)}
                  >
                    <span>검 색</span>
                  </button>
                  <button
                    className="btn btn-primary"
                    onClick={newGroupReg}
                  >
                    <span>신규등록</span>
                  </button>
                </span>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
      </span>
      <div style={{ marginTop: '50px' }}>
        <span>
          총건수 : {totalCount} 현재 페이지번호 : {currentPage}
        </span>
        <table className='col'>
          <thead>
            <tr>
              <th scope='col'> 그룹 코드 </th>
              <th scope='col'> 그룸 명 </th> 
              <th scope='col'> 사용 여부 </th>
              <th scope='col'></th>
            </tr>
          </thead>
          <tbody>
            {groupList.map((item, index)=>{
              return (
                <tr key={index}>
                  <td className="pointer-cursor" >
                    {item.group_code}
                  </td>
                  <td style={{cursor:'pointer'}} onClick={()=>detailCodeList(dcurrentPage, item.group_code)}> {item.group_name} </td>
                  <td> {item.use_yn} </td>
                  <td>
                    <button className="btn btn-secondary btn-sm" id="btn" onClick={()=>searchGroupDetail(item.group_code)}>
                      수정
                    </button>
                  </td>
                </tr>
                )
              })
            }
          </tbody>
        </table>
        {/* 그룹 페이징 처리 */}
        <Pagination 
          currentPage={currentPage}
          totalPage={totalPage}
          blockSize={blockSize}
          onClick={searchGroupList}
        />

      </div>
      <div style={{ marginTop: '60px' }}>
        <span>
          총건수 : {dtotalCount} 현재 페이지번호 : {dcurrentPage}
        </span>
        <span className='fr'>
          <a className='btn btn-primary mx-2 mb-2' name='modal' onClick={newDCodeReg}>
            <span> 신규등록 </span>
          </a>
        </span>
        <table className='col'>
          <thead>
            <tr>
              <th scope='col'>상세 코드</th>
              <th scope='col'>상세코드 명</th>
              <th scope='col'>사용 여부</th>
              <th scope='col'>등록자</th>
              <th scope='col'></th>
            </tr>
          </thead>
          <tbody>
            {dcodeList.map((item,index)=>{
              return (
              <tr key={index}>
                <td> {item.detail_code}</td>
                <td> {item.detail_name} </td>
                <td> {item.use_yn} </td>
                <td> {item.regId} </td>
                <td>
                  <button className="btn btn-secondary btn-sm" id="btnModify" 
                    onClick={()=>searchDetailCode(item.detail_code)}
                  >
                    수정
                  </button>
                </td>
              </tr>
              )
            })}
          </tbody>
        </table>
        {/* 상세 페이징 처리 */}
        <Pagination 
          currentPage={dcurrentPage}
          totalPage={dtotalPage}
          blockSize={blockSize}
          onClick={(cPage)=>detailCodeList(cPage, groupCode)}
        />
      </div>
      <GroupDetailModal
        show={show}
        setShow={setShow}
        action={action}
        gCode={groupCode}
      />
      <DetailCodeModal
        show={dshow}
        setShow={setDshow}
        action={action}
        gCode={groupCode}
        dCode={detailCode}
      />
    </div>
  )
}

export default ComnCodMgr
