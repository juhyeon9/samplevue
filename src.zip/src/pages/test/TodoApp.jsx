import React from 'react'
import Header from '../../components/todo/Header'
import TodoInput from '../../components/todo/TodoInput'
import TodoList from '../../components/todo/TodoList'
import { RecoilRoot } from 'recoil'

const TodoApp = () => {
  return (
    <RecoilRoot>
      <div className="container">
        <div className="row">
          <Header />
        </div>
        <div className="row">
          <TodoInput />
        </div>
        <div className="row">
          <TodoList />
        </div>
      </div>
    </RecoilRoot>
  )
}

export default TodoApp
