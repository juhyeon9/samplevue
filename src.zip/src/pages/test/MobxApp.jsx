//import ObservableTodoStore from "../../components/mobx/ObservableTodoStore";
import { TodoListPage } from "../../components/mobx/TodoList"
const MobxApp = () => {
  //const observableTodoStore = new ObservableTodoStore(); // <할 일 없음>
  //observableTodoStore.addTodo("몹엑스 공부하기"); // 다음 할 일: "몹엑스 공부하기".진척도: 0/1
  //observableTodoStore.addTodo("몹엑스 때려치기"); // 다음 할 일: "몹엑스 공부하기".진척도: 0/2
  //observableTodoStore.todos[0].completed = true; // 다음 할 일: "몹엑스 때려치기".진척도: 1/2
  return (
    <div>
      <TodoListPage />
    </div>
  )
}

export default MobxApp
