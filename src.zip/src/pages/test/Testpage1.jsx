import React from 'react'
import Header from '../../components/test/Header'
import HappyMain from '../../components/test/HappyMain'
import Footer from '../../components/test/Footer'
import Student from '../../components/test/Student'
import Avatar from '../../components/test/Avatar'
import PackingItem from '../../components/test/PackingItem'
import ArrayList from '../../components/test/ArrayList'
import Cup from '../../components/test/Cup'
import Counter from '../../components/test/Counter'
import ClickEvent from '../../components/test/ClickEvent'
import UseStateHook from '../../components/test/UseStateHook'
import UseStateHook2 from '../../components/test/UseStateHook2'
import UseStateHook3 from '../../components/test/UseStateHook3'
import MultiInputBinding from '../../components/test/MultiInputBinding'
import UseRefHook from '../../components/test/UseRefHook'
import Clock from '../../components/test/Clock'
import UseEffectHook from '../../components/test/UseEffectHook'
import AddUserList from '../../components/test/AddUserList'
import UseMemoHook from '../../components/test/UseMemoHook'
import UseCallbackHook from '../../components/test/UseCallbackHook'
import ReactMemoHook from '../../components/test/ReactMemoHook'
import UseReducerHook from '../../components/test/UseReducerHook'
import UseReducerHook2 from '../../components/test/UseReducerHook2'
import CustomHook from '../../components/test/CustomHook'
import ContextAPI from '../../components/test/ContextAPI'
import ContextAPI2 from '../../components/test/ContextAPI2'
import UserIdHook from '../../components/test/UserIdHook'
import ImmerTest from '../../components/test/ImmerTest'
import LifeCycleApp from '../../components/test/LifeCycleApp'
import ReduxTest from '../../components/test/ReduxTest'
import ReactQueryTest from '../../components/test/ReactQueryTest'
import UseDeferredValueHook from '../../components/test/UseDeferredValueHook'
const Testpage1 = () => {
  return (
    <div>
      <Header />
      <hr />
      <HappyMain />
      <hr />
      <h3>2. Props 테스트</h3>
      <Student />
      <Student name="손흥민" age={32} isStudent={false} />
      <Student name="김민재" age={28} isStudent={true} />
      <Avatar person={{name:'Lin Lanying', imageId:'1bX5QH6'}} size={100}/>
      <Avatar person={{name:'Katsuko Saruhashi', imageId:'YfeOqp2'}} size={80}/>
      <hr />
      <h3>3. 조건부 렌드링</h3>
      <PackingItem />
      <hr />
      <h3>4. 렌드링 목록</h3>
      <ArrayList />
      <hr />
      <h3>5. 렌드링전에 변수 변경 금지</h3>
      <Cup />
      <Cup />
      <Cup />
      <hr />
      <h3>6. 클릭이벤트</h3>
      <Counter />
      <ClickEvent />
      <hr />
      <h3>7. useState hooks 사용: 상호작용 및 상태 업데이트</h3>
      <UseStateHook />
      <UseStateHook2 />
      <UseStateHook3 />
      <hr />
      <h3>8. 여러개 Input 상태관리</h3>
      <MultiInputBinding />
      <hr />
      <h3>9. useRef로 특정DOM 선택하기(렌드링되지않음)</h3>
      <UseRefHook />
      <hr />
      <h3>10. Clock만들기</h3>
      <Clock />
      <hr />
      <h3>11. useEffect hooks사용</h3>
      <UseEffectHook />
      <hr />
      <h3>12. 배열에 항목추가/삭제하기</h3>
      <AddUserList />
      <hr />
      <h3>13. useMemo를 사용하여 연산한 값 재사용하기</h3>
      <UseMemoHook />
      <hr />
      <h3>14. useCallback를 사용하여 함수 재사용하기</h3>
      <UseCallbackHook />
      <hr />
      <h3>15. React.memo를 사용한 컴포넌트 메모이징 하여 리렌더링 방지</h3>
      <ReactMemoHook />
      <hr />
      <h3>16. useReducer를 사용하여 상태 업데이트 로직 분석하기</h3>
      <UseReducerHook />
      <UseReducerHook2 />
      <hr />
      <h3>17. 커스텀 Hook</h3>
      <CustomHook />
      <hr />
      <h3>18. Context API 사용한 전역 값 관리</h3>
      <ContextAPI />
      <ContextAPI2 />
      <hr />
      <h3>19. UserId Hook</h3>
      <UserIdHook />
      <hr />
      <h3>20. Immer를 사용한 불변성 관리</h3>
      <ImmerTest />
      <hr />
      <h3>21. Life Cycle(생명주기)</h3>
      <LifeCycleApp />
      <hr />
      <h3>22. Redux 상태관리</h3>
      <ReduxTest />
      <hr />
      <h3>23. Todo List(Recoil사용)</h3>
      <hr />
      <h3>24. React Query</h3>
      <ReactQueryTest />
      <hr />
      <h3>25. UseDeferredValue Hook</h3>
      <UseDeferredValueHook />

      <Footer />
    </div>
  )
}

export default Testpage1
