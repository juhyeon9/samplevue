import React, {useLayoutEffect} from 'react'
import styled from 'styled-components'
import LeftMenu from '../components/common/LeftMenu'
import { Outlet } from 'react-router-dom'

const Wrapper = styled.div`
  position: 'absolute';
  width: '950px';
  height: '800px';
`

const Dashboard = () => {
  useLayoutEffect(() => {
    const loginId = sessionStorage.getItem('loginId');
    if(!loginId) {
      alert('로그인이 필요합니다.');
      window.location.replace('/')
    }
  }, [])
  return (
    <div id='dashboard'>
      <div id='wrap_area'>
        <div id='container'>
          <ul>
            <li className='lnb'>{<LeftMenu />}</li>
            <li className='contents'>
              <div className='content'>
                <Wrapper>
                  <Outlet />
                </Wrapper>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </div>
  )
}

export default Dashboard
