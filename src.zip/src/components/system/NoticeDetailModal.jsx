import React from 'react'
import { useState, useEffect } from 'react';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const NoticeDetailModal = ({show, setShow, action, noticeNo}) => {
  const initInputValue = {
    noticeNo: '',
    noticeTitle: '',
    noticeContent: '',
    userName: '',
    fileNo: 0,
    fileName:'',
    fileRelativePath: ''
  }
  const [inputs, setInputs] = useState(initInputValue);
  const {noticeTitle, noticeContent, userName, fileNo, fileName, fileRelativePath} = inputs;
  const navigate = useNavigate();

  const [image, setImage] = useState('');//이미지객체
  const [imageSrc, setImageSrc] = useState('');//이미지객체src
  //D: 첨부삭제하고 저장하는 경우
  //M: 첨부삭제하고 다시 첨부추가하여 저장하는 경우(첨부수정)
  //A: 첨부가 없었는데 첨부추가하여 저장하는겨우
  const [fileStatus, setFileStatus] = useState('');//파일 첨부 상태(A, M, D)

  //const [fileRelativePath, setFileRelativePath] = useState('');//첨부파일 물리적경로

  //multi input binding
  const onChange = (e) => {
    const {name, value} = e.target; //e.target에서 name과 value를 추출
    setInputs({
      ...inputs,  //기존의 input객체를 복사
      [name]: value //name 키를 가진 값을 value로 세팅
    })
    
  }

  //로드시 상세조회
  useEffect(()=>{
    console.log('noticeNo::' + noticeNo);
    if(noticeNo) searchDeatil();
    else {
      setFileStatus("");
      setImageSrc("");
      setInputs({
        ...initInputValue,
        userName: sessionStorage.getItem('userNm')
      });
    }
  }, [noticeNo])

  //공지상세조회
  const searchDeatil = () =>{
    const params = new URLSearchParams();
    params.append('noticeNo', noticeNo);
    axios.post('/api/system/noticeDetail.do', params)
      .then(res=>{
        console.log(res);
        const result = res.data.result;
        setInputs({
          ...inputs,
          noticeTitle: result.notice_title,
          noticeContent: result.notice_content,
          userName: result.user_name,
          fileNo: !result.file_no?0:result.file_no,
          fileName: result.file_name,
          fileRelativePath: result.file_relative_path
        })

        setImageSrc(result.file_relative_path);

      })
      .catch(err=>{
        console.log(err)
      })
  }
  
  const modalClose = () => {
    setShow(false);
  }

  //저장
  const saveNotice = () => {
    console.log('save notice start!!');
    if(action === 'N') {//신규
      //const params = new URLSearchParams();
      const formData = new FormData();
      formData.append('noticeTitle', noticeTitle);
      formData.append('noticeContent', noticeContent);
      //params.append('noFile','noFile');
      if(image.size > 0) {
        formData.append('file', image);
        formData.append('isFile', 'isFile');
      }
      //axios.post('/api/system/noticeInsert.do', params)
      const options = {
        method: "post",
        url: "/api/system/noticeInsert.do",
        header: {
          "Content-Type": "multipart/form-data"
        },
        data: formData
      }
      axios(options)
        .then(res=>{
          alert('저장이 완료되었습니다.');
          modalClose();
          //화면리프레쉬
          navigate(0);

        })
        .catch(err=>{
          console.log(err);
        })

    } else if(action === 'U') { //수정
      console.log(noticeTitle, noticeContent)
      //const params = new URLSearchParams();
      const formData = new FormData();
      formData.append('noticeNo', noticeNo);
      formData.append('noticeTitle', noticeTitle);
      formData.append('noticeContent', noticeContent);
      console.log(image.size);
      if(image.size > 0) {
        formData.append('file', image);
        formData.append('isFile','isFile');
      } else if(fileStatus !== 'D'){
        formData.append('noFile','noFile');
      }

      if(fileStatus === 'D') { //첨부파일만 삭제하고 저당
        formData.append("deleted", "deleted");
      } else if(fileStatus === 'M') { //첨부삭제후 첨부추가 하여 저장
        formData.append("modified", "modified");
      } else if(fileStatus === 'A') { //첨부없었는데 첨부추가 하여 저장
        formData.append("added", "added");
      } else {
        formData.append('noFile','noFile');
      } 
      formData.append("fileNo", fileNo+'');
      formData.append("fileNm", fileName);


      //formData.append('noFile','noFile');
      //axios.post('/api/system/noticeUpdate.do', formData)
      const options = {
        method: "post",
        url: "/api/system/noticeUpdate.do",
        header: {
          "Content-Type": "multipart/form-data"
        },
        data: formData,
      }
      axios(options)
        .then(res=>{
          alert('수정이 완료되었습니다.');
          modalClose();
          //화면리프레쉬
          navigate(0);

        })
        .catch(err=>{
          console.log(err);
        })

    }
  }
  const deleteNotice = () => {
    if(!confirm('삭제하시겠습니까?')) return;
    const params = new URLSearchParams();
    params.append('noticeNo', noticeNo);
    axios.post('/api/system/noticeDelete.do', params)
    .then(res=>{
      alert('삭제가 완료되었습니다.');
      modalClose();
      //화면리프레쉬
      navigate(0);

    })
    .catch(err=>{
      console.log(err);
    })
  }
  
  //미리보기
  const previewFile = (e) => {
    const fileInput = e.target;
    console.log(fileInput.files[0]);
    setImage(fileInput.files[0]);
    if(fileInput.files && fileInput.files[0]) {
      //미리보기
      const reader = new FileReader();
      reader.readAsDataURL(fileInput.files[0]);
      reader.onload = (e) => {
        //console.log(e.target.result);
        setImageSrc(e.target.result);
        if(action==='U' && fileNo === 0) {
          setFileStatus('A');
        } else if(action==='U' && fileNo !== 0) {
          setFileStatus('M');
        }
      }
    }
  }

  //첨부삭제
  const deleteFile = () => {
    setFileStatus("D");
    setImageSrc("");
    setInputs({
      ...inputs,
      fileRelativePath: '',
    })
  }
  
  return (
    <div>
     <Modal show={show} onHide={modalClose} animation={true}>
        <Modal.Header closeButton>
          <Modal.Title>{action==='N'?'공지등록':'공지상세'}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
        <div className="row mb-1">
          <label htmlFor="noticeNo" className="col-sm-3 col-form-label">공지번호</label>
          <div className="col-sm-9">
            <input type="input" name="noticeNo" className="form-control" readOnly value={noticeNo} />
          </div>
        </div>
        <div className="row mb-1">
          <label htmlFor="userName" className="col-sm-3 col-form-label">작성자</label>
          <div className="col-sm-9">
            <input type="input" name="userName" className="form-control" readOnly value={userName}
            />
          </div>
        </div>
        <div className="row mb-1">
          <label htmlFor="noticeTitle" className="col-sm-3 col-form-label">제목</label>
          <div className="col-sm-9">
            <input 
              type="input" 
              name="noticeTitle" 
              className="form-control" 
              value={noticeTitle}
              onChange={onChange}
            />
          </div>
        </div>
        <div className="row mb-1">
          <label htmlFor="noticeContent" className="col-sm-3 col-form-label">공지내용</label>
          <div className="col-sm-9">
            <textarea 
              rows="3" 
              cols="300" 
              className="form-control" 
              name="noticeContent" 
              value={noticeContent}
              onChange={onChange}
            />
          </div>
        </div>
        {(fileRelativePath === null || fileRelativePath==='') && (<div className="row mb-1" >
          <label htmlFor="file" className="col-sm-3 col-form-label">첨부</label>
          <div className="col-sm-9">
            <input 
              type="file" 
              id="file" 
              className="inputTxt p100"
              onChange={previewFile} 
              accept="image/*" 
              />
          </div>
        </div>)}
        {(action === 'U' && fileRelativePath !== null && fileRelativePath!=='') && (<div className="row mb-1">
          <label htmlFor="fileName" className="col-sm-3 col-form-label">첨부</label>
          <div className="col-sm-9">
            <input readonly id="fileName" value={fileName}/>
            <a className="btn" id="download" href={fileRelativePath} download>
              <button className="btn btn-secondary btn-sm">다운로드</button>
            </a>
            <button className="btn btn-secondary btn-sm" onClick={deleteFile}>삭제</button>
          </div>
        </div>)}
        <div className="row mb-0">
          <label htmlFor="noticeContent" className="col-sm-3 col-form-label">미리보기</label>
          <div className="col-sm-9">
            <img id="preview" 
              src={imageSrc} 
              width="345" 
              height="200" 
              className="filePreview" 
              alt="미리보기"
            />
          </div>
        </div>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="primary" onClick={saveNotice}>
            저장
          </Button>
          {action ==='U' && <Button variant="danger" onClick={deleteNotice}>
            삭제
          </Button>}
          <Button variant="primary" onClick={modalClose}>
            닫기
          </Button>
        </Modal.Footer>
      </Modal>
    </div>  
  )
}

export default NoticeDetailModal
