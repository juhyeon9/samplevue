import React, {useState, useEffect} from 'react'
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const DetailCodeModal = ({show, setShow, action, gCode, dCode}) => {
  const initFormValue = {
    groupCode: '',
    detailCode: '',
    detailName: '',
    note: '',
    useYn: 'N',
    loginId: '',
  }

  const [inputs, setInputs] = useState(initFormValue);
  const {groupCode, detailCode, detailName, note, useYn, loginId} = inputs;
  const navigate = useNavigate();

  //multi input binding
  const onChange = (e) => {
    const {name, value} = e.target; //e.target에서 name과 value를 추출
    setInputs({
      ...inputs,  //기존의 input객체를 복사
      [name]: value //name 키를 가진 값을 value로 세팅
    })
    
  }

  //로드시 상세코드 조회
  useEffect(()=>{
    if(dCode) searchDetailCode()
    else {
      setInputs({
        ...initFormValue,
        loginId: sessionStorage.getItem('loginId'),
        groupCode: gCode,
        detailCode: dCode,
      });
    }
  }, [gCode, dCode])

  //상세코드 조회
  const searchDetailCode = () => {
    const params = new URLSearchParams();
    params.append('groupCode', gCode);
    params.append('detailCode', dCode);
    axios.post('/api/system/selectDetailCode.do', params)
      .then(res=>{
        console.log(res);
        const result = res.data.detailCode;
        setInputs({
          ...inputs,
          groupCode: result.group_code,
          detailCode: result.detail_code,
          detailName: result.detail_name,
          note: result.note,
          useYn: result.use_yn==='undefined'?'N':result.use_yn,
        })

      })
      .catch(err=>{
        console.log(err)
      })
  }

  //저장
  const saveDetail = () => {
    console.log('save group code start!!');
    if(action === 'I') {//신규
      const params = new URLSearchParams();
      params.append('igroupcode', groupCode);
      params.append('idetailcode', detailCode);
      params.append('idetailname', detailName);
      params.append('idnote', note);
      params.append('iduseyn', useYn);
      params.append('loginId', loginId);
      params.append('action', 'I');
      
      axios.post('/api/system/saveDetailCode.do', params)
        .then(res=>{
          alert('저장이 완료되었습니다.');
          modalClose();
          //화면리프레쉬
          navigate(0);

        })
        .catch(err=>{
          console.log(err);
        })

    } else if(action === 'U') { //수정
      const params = new URLSearchParams();
      params.append('igroupcode', groupCode);
      params.append('idetailcode', detailCode);
      params.append('idetailname', detailName);
      params.append('idnote', note);
      params.append('iduseyn', useYn);
      params.append('loginId', loginId);
      params.append('action', 'U');
      
      axios.post('/api/system/saveDetailCode.do', params)
        .then(res=>{
          alert('수정이 완료되었습니다.');
          modalClose();
          //화면리프레쉬
          navigate(0);

        })
        .catch(err=>{
          console.log(err);
        })
    }
  }

  //삭제
  const deleteDetail = () => {
    if(!confirm('삭제하시겠습니까?')) return;
    const params = new URLSearchParams();
    params.append('igroupcode', gCode);
    params.append('idetailcode', dCode);
    params.append('action', 'D');
    axios.post('/api/system/saveDetailCode.do', params)
    .then(res=>{
      alert('삭제가 완료되었습니다.');
      modalClose();
      //화면리프레쉬
      navigate(0);

    })
    .catch(err=>{
      console.log(err);
    })
  }

  const modalClose = () => {
    setShow(false);
  }
  return (
    <div>
     <Modal show={show} onHide={modalClose} animation={true}>
        <Modal.Header closeButton>
          <Modal.Title>{action==='I'?'상세코드신규':'상세코드 수정'}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
        <div className="row mb-1">
          <label htmlFor="groupCode" className="col-sm-3 col-form-label">그룹코드</label>
          <div className="col-sm-9">
            <input type="input" name="groupCode" className="form-control" readonly value={gCode} />
          </div>
        </div>
        <div className="row mb-1">
          <label htmlFor="detailCode" className="col-sm-3 col-form-label">상세코드</label>
          <div className="col-sm-9">
            <input type="input" name="detailCode" className="form-control" value={detailCode}
              onChange={onChange}
            />
          </div>
        </div>
        <div className="row mb-1">
          <label htmlFor="detailName" className="col-sm-3 col-form-label">상세코드명</label>
          <div className="col-sm-9">
            <input type="input" name="detailName" className="form-control" value={detailName}
              onChange={onChange}
            />
          </div>
        </div>
        <div className="row mb-1">
          <label htmlFor="note" className="col-sm-3 col-form-label">내용</label>
          <div className="col-sm-9">
            <textarea 
              rows="3" 
              cols="300" 
              className="form-control" 
              name="note" 
              value={note}
              onChange={onChange}
            />
          </div>
        </div>
        <div className="row mb-1">
          <label htmlFor="useYn" className="col-sm-3 col-form-label">사용여부</label>
            <div className="col-sm-9">
              사용
              <input type="radio" 
                name="useYn" 
                value='Y'
                checked={useYn==='Y'}
                onChange={onChange}
              />
              미사용
              <input type="radio" 
                name="useYn" 
                value='N'
                checked={useYn==='N'}
                onChange={onChange}
              />
            </div>
          </div>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="primary" onClick={saveDetail}>
            저장
          </Button>
          {action ==='U' && <Button variant="danger" onClick={deleteDetail}>
            삭제
          </Button>}
          <Button variant="primary" onClick={modalClose}>
            닫기
          </Button>
        </Modal.Footer>
      </Modal>
    </div> 
  )
}
export default DetailCodeModal
