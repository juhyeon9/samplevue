import React from 'react'
import { useRecoilValue, useSetRecoilState } from 'recoil'
import inputState from './state/inputState'
import todosState from './state/todosState'

const TodoInput = () => {
  const inputValue = useRecoilValue(inputState)
  const setInputValue = useSetRecoilState(inputState)
  const setTodos = useSetRecoilState(todosState)
  const handleChange = (e) => {
    setInputValue(e.target.value)
  }

  //할일 추가 이벤트
  const handleAdd = (e) => {
    if(e.keyCode===13) {
      setTodos(prevTodos => [
        ...prevTodos,
        {
          id: prevTodos.length,
          title: e.target.value,
          isCompleted: false,
          isView: true,
        }
      ]);
      setInputValue('');
    }
  }
  return (
    <div>
      <input 
        type="text"
        className="form-control mb-3"
        placeholder='할일을 입력해주세요.'
        value={inputValue}
        onChange={handleChange}
        onKeyUp={handleAdd}
      />
    </div>
  )
}

export default TodoInput
