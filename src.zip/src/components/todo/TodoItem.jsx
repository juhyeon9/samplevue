import React from 'react'
import { useState } from 'react'

const TodoItem = ({id, title, isCompleted, isView, onToggle, onRemove, onUpdate}) => {

  const [inputTitle, setInputTitle] = useState(title)

  const clickUpdate= () => {
    document.getElementById('todo'+id).disabled = false;
    document.getElementById('todo'+id).focus();
  }

  const handleChangeTitle = (e) => {
    setInputTitle(e.target.value);
  }

  const handleKeyUpTitle = (e) => {
    if(e.keyCode===13) {
      onUpdate(inputTitle);
      document.getElementById('todo'+id).disabled = true;
    }
  }

  return (
    <div className='input-group' style={{display:isView?'':'none'}}>
      <div className='input-group-text'>
        <input 
          type='checkbox'
          className='form-check-input'
          checked={isCompleted}
          onClick={onToggle}
        />
      </div>
      <input id={'todo'+id} key={id}
        type='text'
        className='form-control'
        value={inputTitle}
        disabled
        onChange={handleChangeTitle}
        onKeyUp={handleKeyUpTitle}
      />
      <button
        type='button'
        className='btn btn-outline-secondary'
        onClick={onRemove}
      >
        삭제
      </button>
      <button
        type='button'
        className='btn btn-outline-secondary'
        onClick={clickUpdate}
      >
        수정
      </button>
    </div>
  )
}

export default TodoItem
