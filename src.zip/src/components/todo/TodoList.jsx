import React from 'react'
import { useRecoilState } from 'recoil'
import TodoItem from './TodoItem'
import todosState from './state/todosState'

const TodoList = () => {
  const [todos,  setTodos] = useRecoilState(todosState)
  //체크박스 토글
  const handleToggle = (id) => {
    setTodos(todos.map(todo=>{
      return todo.id === id ? {...todo, isCompleted: !todo.isCompleted}:todo;
    }))
  }
  //삭제
  const handleRemove = (id) => {
    setTodos(todos.filter(todo=>{
      return todo.id != id;
    }))
  }
  //타이틀 수정
  const handleUpdateTitle = (id, title) => {
    console.log(id, title);
    setTodos(todos.map(todo=> {
      return todo.id === id ? {...todo, title} : todo;
    }))
  }
  return (
    <div>
      {todos.map(todo =>(
        <TodoItem 
          key={todo.id}
          id={todo.id}
          title={todo.title}
          isCompleted={todo.isCompleted}
          isView={todo.isView}
          onToggle={()=>handleToggle(todo.id)}
          onRemove={()=>handleRemove(todo.id)}
          onUpdate={(title)=>handleUpdateTitle(todo.id, title)}
        />
      ))}
    </div>
  )
}

export default TodoList
