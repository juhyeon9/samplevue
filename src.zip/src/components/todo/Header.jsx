import React from 'react'
import { useRecoilState } from 'recoil'
import todosState from './state/todosState';

const Header = () => {
  const [todos, setTodos] = useRecoilState(todosState);

  //전체리스트
  const handleAll = () => {
    setTodos(todos.map(todo => ({...todo, isView: true})))
  }
  //작업중 리스트
  const handleActive = () => {
    setTodos(todos.map(todo => ({...todo, isView: !todo.isCompleted})))
  }
  //완료 리스트
  const handleCompleted = () => {
    setTodos(todos.map(todo => ({...todo, isView: todo.isCompleted})))
  }
  return (
    <header>
      <h1>MY-TODO-LIST</h1>
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="#!" onClick={handleAll}>전체</a>
          </li>
          <li class="breadcrumb-item">
            <a href="#!" onClick={handleActive}>작업 중</a>
          </li>
          <li class="breadcrumb-item active" aria-current="page">
            <a href="#!" onClick={handleCompleted}>완료</a>
          </li>
        </ol>
      </nav>
    </header>
  )
}

export default Header
