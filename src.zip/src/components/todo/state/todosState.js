import { atom } from "recoil";

export default atom( {
  // key의 값은 항상 고유값이어야 합니다.
  key: 'todos',  //unique ID
  default: [
    {
      id:0,
      title:'Vue 배우기',
      isCompleted: false,
      isView:true
    },
    {
      id:1,
      title:'React 배우기',
      isCompleted: false,
      isView:true
    },
    {
      id:2,
      title:'Nexacro 배우기',
      isCompleted: true,
      isView:true
    },

  ], //initial value
})