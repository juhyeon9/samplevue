import { atom } from "recoil";

export default atom( {
  // key의 값은 항상 고유값이어야 합니다.
  key: 'inputState',  //unique ID
  default: '', //initial value
})