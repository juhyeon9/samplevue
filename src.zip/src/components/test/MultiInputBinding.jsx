import React from 'react'
import { useState, useRef } from 'react'

const MultiInputBinding = () => {
  const [inputs, setInputs] = useState({name:'', nickName:''})
  const {name, nickName} = inputs; //구조분해 할당을 통해 값 추출
  const nameInput = useRef();  //focus 주기 위해 사용

  //multi input binding
  const onChange = (e) => {
    const {name, value} = e.target; //e.target에서 name과 value를 추출
    setInputs({
      ...inputs,  //기존의 input객체를 복사
      [name]: value //name 키를 가진 값을 value로 세팅
    })
    
  }
  //초기화
  const onReset = () => {
    setInputs({name:'', nickName:''})
    console.log(nameInput);
    nameInput.current.focus();
  }
  return (
    <div>
      <input name="name"
        placeholder="이름"
        value={name}
        onChange={onChange}
        ref={nameInput}
        />
      <input name="nickName"
        placeholder="닉네임"
        value={nickName}
        onChange={onChange}
        />
      <br />
      <button className="btn btn-primary" onClick={onReset}>초기화</button>
        <div>
          <b>값:{name} ({nickName})</b>
        </div>
    </div>
  )
}

export default MultiInputBinding
