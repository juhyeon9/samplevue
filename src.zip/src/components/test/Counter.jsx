import React from 'react'
import { useState } from 'react'

const Counter = () => {
  let [count, setCount] = useState(0);
  const decrement = () =>{
    //count = count -1;
    //console.log(count)
    //setCount(count-1)
    //setCount(count-1)
    //setCount(count-1)

    setCount(c=>c-1)
    setCount(c=>c-1)
  }

  const reset = () => {
    setCount(0)
  }
  const increment = () => {
    setCount(c=>c+1)
  }
  return (
    <div>
      <p>{count}</p>
      <button className="btn btn-primary" onClick={decrement}>감소</button>
      <button className="btn btn-secondary" onClick={reset}>초기화</button>
      <button className="btn btn-primary" onClick={increment}>증가</button>
    </div>
  )
}

export default Counter
