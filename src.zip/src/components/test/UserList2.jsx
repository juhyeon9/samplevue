import React from 'react'
import { useEffect } from 'react'
import { UserDispatch } from './ContextAPI2'
import { useContext } from 'react'

const UserList = ({users}) => {

  const User = ({user}) => {
    const dispatch = useContext(UserDispatch);
    useEffect(() => {
      console.log('컴포넌트가 화면에 나타남')
      return () => {
        console.log('컴포넌트가 화면에서 사라짐')
      }
    }, [user])
    return (
      <div>
        <b
          style={{cursor: 'pointer', color:user.active?'green':'black'}}
          onClick={()=>{
            dispatch({type: 'TOGGLE_USER', id:user.id})
          }}
        >{user.username}</b><span>({user.email})</span>
        <button className="btn btn-danger btn-sm" 
          onClick={()=>{
            dispatch({type: 'REMOVE_USER', id:user.id})
          }}
        >
          삭제
        </button>
      </div>
    )
  }

  return (
    <div>
      {
        users.map((user, index) => <User user={user} />)
      }
    </div>
  )
}

export default React.memo(UserList)
