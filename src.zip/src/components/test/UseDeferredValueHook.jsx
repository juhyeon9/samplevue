import React from 'react'
import { useDeferredValue, useState } from 'react'

//상태 값 변화에 가장 낮은 우선순위를 지정하기 위한 훅, 값을 래핑
const UseDeferredValueHook = () => {
  const [count1, setCount1] = useState(0)
  const [count2, setCount2] = useState(0)
  const [count3, setCount3] = useState(0)
  const [count4, setCount4] = useState(0)

  const deferredValue = useDeferredValue(count2);

  const increase = () => {
    setCount1(count1+1);
    setCount2(count2+1);
    setCount3(count3+1);
    setCount4(count4+1);
  }

  console.log('count1:::' + count1)
  console.log('count2:::' + count2)
  console.log('count3:::' + count3)
  console.log('count4:::' + count4)
  console.log('deferredValue:::' + deferredValue)
  return (
    <div>
      <button className='btn btn-primary' onClick={increase}>클릭</button>
    </div>
  )
}

export default UseDeferredValueHook
