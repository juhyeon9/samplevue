import React from 'react'

const Footer = () => {
  return (
    <div>
      <hr />
      <footer>
        <p>&copy; 2024 Happy Job</p>
      </footer>
    </div>
  )
}

export default Footer
