import React from 'react'

// 배열 메소드를 사용해서 데이터 배열을 조작 할 수 있다.
// map(), filter()를 사용하여 배열, 필터링된 배열을 반환한다.
const ArrayList = () => {
  const footBallMemberList = ["손흥민", "이강인", "김민재", "황희찬", "조규성"]
  const fbMemberList = footBallMemberList.map((member,index) => <li key={index}>{member}</li>)
  return (
    <div>
      <ul>
        {fbMemberList}
      </ul>
      <ul>
        {footBallMemberList.filter((member, index) => index < 3)}
      </ul>
    </div>
  )
}

export default ArrayList
