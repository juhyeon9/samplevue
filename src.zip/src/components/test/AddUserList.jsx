import React from 'react'
import { useState, useRef } from 'react'
import CreateUser from './CreateUser'
import UserList from './UserList'

const AddUserList = () => {
  const [inputs, setInputs] = useState({username:'', email:''})
  const {username, email} = inputs;
  const nextId = useRef(4);
  const [users, setUsers] = useState([
    {
      id: 1,
      username: '손흥민',
      email: 'sonhm@gmail.com'
    },
    {
      id: 2,
      username: '메시',
      email: 'mesi@gmail.com'
    },
    {
      id: 3,
      username: '음바페',
      email: 'umbp@gmail.com'
    }
  ])

  const onChange = (e) => {
    const {name, value} = e.target; //e.target에서 name, value추출
    setInputs({
      ...inputs,  //기존의 inputs객체를 복사
      [name]: value  //name키를 가진값을 value로 설정
    })
  }
  const onCreate = (e) => {
    //사용자객체
    const user= {
      id: nextId,
      username,
      email
    }

    //사용자객체 추가
    setUsers([...users, user])

    setInputs({username:'', email:''})

    nextId.current += 1;
  }
  //사용자삭제
  const onRemove = (id) => {
    setUsers(users.filter(user=>user.id != id))
  }
  //사용자토글
  const onToggle = (id) => {
    console.log(id);
    console.log(JSON.stringify(users))
    setUsers(
      users.map(user=> user.id===id?{...user, active: !user.active}:user)
    )
  }
  return (
    <div>
      <CreateUser 
        username={username}
        email={email}
        onChange={onChange}
        onCreate={onCreate}
      />
      <UserList 
        users={users}
        onRemove={onRemove}
        onToggle={onToggle}
      />
    </div>
  )
}

export default AddUserList
