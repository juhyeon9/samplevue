import React from 'react'
import { useState, useReducer } from 'react'

const initialState = {count: 0};
const countReducer = (state, action) => {
  switch (action.type) {
    case 'INCREMENT':
      return {count: state.count + 1};
    case 'DECREMENT':
      return {count: state.count - 1};
    default:
      throw new Error();
  }
}

//useReducer : 컴포넌트의 상태 업데이트 로직을 분리시킬 수 있다.
//           즉 로직을 recuder함수에서 처리한다. 로직을 은닉할 수 있다.
const UseReducerHook = () => {
  //const [number, setNumber] = useState(0);
  const [state, countDispatch] = useReducer(countReducer, initialState)

  const onIncrement = () => {
    //setNumber(preNumber => preNumber + 1)
    countDispatch({type: 'INCREMENT'})
  }

  const onDecrement= () => {
    //setNumber(preNumber => preNumber - 1)
    countDispatch({type: 'DECREMENT'})
  }

  return (
    <div>
      <h1>{ state.count }</h1>
      <button className="btn btn-primary" onClick={onIncrement}>증가</button>
      <button className="btn btn-primary" onClick={onDecrement}>감소</button>
    </div>
  )
}

export default UseReducerHook
