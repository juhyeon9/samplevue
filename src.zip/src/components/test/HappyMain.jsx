import React from 'react'

const HappyMain = () => {
  return (
    <div>
      <main>
        <h3>1. 좋아하는 과일</h3>
        <ul>
          <li>바나나</li>
          <li>수박</li>
          <li>오렌지</li>
        </ul>
      </main>
    </div>
  )
}

export default HappyMain
