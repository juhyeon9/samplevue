import React from 'react'

const CreateUser = ({username, email, onChange, onCreate}) => {
  return (
    <div>
      <input 
        name="username"
        placeholder='계정명'
        value={username}
        onChange={onChange}
      />
      <input 
        name='email'
        placeholder='이메일'
        value={email}
        onChange={onChange}
      />
      <button className="btn btn-primary" onClick={onCreate}>등록</button>
    </div>
  )
}

export default React.memo(CreateUser)
