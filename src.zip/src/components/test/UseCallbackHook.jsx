import React from 'react'
import { useState, useRef, useMemo, useCallback } from 'react'
import CreateUser from './CreateUser'
import UserList from './UserList'

const countActiveUsers = (users) => {
  //console.log('활성 사용자 수를 계산하는 중...')
  return users.filter(user => user.active).length;
}

//useCallback: 렌드링 될 때 특정함수를 재사용
//함수 안에서 사용하는 상태 혹은 Props가 있다면 deps안에 포함시켜라.
const UseCallbackHook = () => {
  const [inputs, setInputs] = useState({username:'', email:''})
  const {username, email} = inputs;
  const nextId = useRef(4);
  const [users, setUsers] = useState([
    {
      id: 1,
      username: '손흥민',
      email: 'sonhm@gmail.com'
    },
    {
      id: 2,
      username: '메시',
      email: 'mesi@gmail.com'
    },
    {
      id: 3,
      username: '음바페',
      email: 'umbp@gmail.com'
    }
  ])

  const onChange = (e) => {
    const {name, value} = e.target; //e.target에서 name, value추출
    setInputs({
      ...inputs,  //기존의 inputs객체를 복사
      [name]: value  //name키를 가진값을 value로 설정
    })
  }
  const onCreate = (e) => {
    //사용자객체
    const user= {
      id: nextId,
      username,
      email
    }

    //사용자객체 추가
    setUsers([...users, user])

    setInputs({username:'', email:''})

    nextId.current += 1;
  }
  //사용자삭제
  /*
  const onRemove = (id) => {
    console.log('사용자 삭제 호출~~~')
    setUsers(users.filter(user=>user.id != id))
  }
    */
  
  const onRemove = useCallback((id) => {
    console.log('사용자 삭제 호출~~~')
    setUsers(users.filter(user=>user.id != id))
  }, [users])

  //사용자토글
  const onToggle = useCallback((id) => {
    console.log(id);
    console.log(JSON.stringify(users))
    setUsers(
      users.map(user=> user.id===id?{...user, active: !user.active}:user)
    )
  },[users])

  //input 값을 바꿀때 마다 렌드링때문에 계속 호출 되는 문제 발생 하는데
  //useMemo(func, deps) 사용하면 이전에 계산한 값을 재사용(deps가 바뀌면 func호출)함
  const count = useMemo(()=>countActiveUsers(users),[users]);
  //const count = countActiveUsers(users);

  return (
    <div>
      <CreateUser 
        username={username}
        email={email}
        onChange={onChange}
        onCreate={onCreate}
      />
      <UserList 
        users={users}
        onRemove={onRemove}
        onToggle={onToggle}
      />
      <div>활성 사용자 수: {count}</div>
    </div>
  )
}

export default UseCallbackHook
