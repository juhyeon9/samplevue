import React from 'react'
import { useState, useEffect, useRef } from 'react'
const CounterFunction = () => {
  const [number, setNumber] = useState(0)

  useEffect(()=>{
    console.log('componentDidMount[Function]')
    return () => {
      console.log('componentWillUnmount[Function]')
    }
  }, [])

  const mounted = useRef(false)
  useEffect(() => {
    if(!mounted.current) {
      mounted.current = true
    } else {
      console.log('componentDidUpdate[Function]')
    }
  })

  const increment = () => {
    setNumber(number+1)
  }
  const decrement = () => {
    setNumber(number-1)
  }
  return (
    <div>
      <h1>Function Counter</h1>
      <div>value: {number}</div>
      <button className="btn btn-primary" onClick={increment}>증가</button>
      <button className="btn btn-primary" onClick={decrement}>감소</button>
      
    </div>
  )
}

export default CounterFunction
