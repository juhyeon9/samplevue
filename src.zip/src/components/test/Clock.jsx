import React from 'react'
import { useState, useEffect } from 'react'

const Clock = () => {
  let datetime = new Date().toLocaleTimeString();
  const [clockTime, setClockTime] = useState(datetime)

  const updateTime = () => {
    datetime = new Date().toLocaleTimeString();
    setClockTime(datetime);
  }
  useEffect(()=>{
    const intervalID = setInterval(updateTime, 500 );
    return () => { //cleanup함수(setInterval 실행하기 직전에 실행)
      clearInterval(intervalID); //자원반환
    }
  },[datetime])
  return (
    <div>
      <h1>{clockTime}</h1>
    </div>
  )
}

export default Clock
