import React from 'react'
import { Item, Item2, Item3 } from '../common/commonFunction'

// if명령문, 연산자 && 와 같은 Javascript 구문을 사용하여
// JSX를 조건부로 렌더링할 수 있다.
const PackingItem = () => {
  return (
    <>
      <h2>여행품목 패킹</h2>
      <ul>
        <Item name="침낭" isPacked={true} ></Item>
        <Item name="코펠" isPacked={false} ></Item>
        <Item2 name="라면" isPacked={true} ></Item2>
        <Item2 name="텐트" isPacked={false} ></Item2>
        <Item3 name="버너" isPacked={false} ></Item3>
        <Item3 name="삼겹살" isPacked={true} ></Item3>
      </ul>
    </>
  )
}

export default PackingItem
