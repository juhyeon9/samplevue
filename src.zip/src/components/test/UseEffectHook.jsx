import React from 'react'

//useEffect()  : 다음중 하나 일 때 수행하도록 반응하는 HOOK;
//       1) 렌드링
//       2) 마운트 될 때
//       3) 상태값이 변경 될 때
// useEffect(function, [dependencies])

// 1. useEffect(()=>{})  //매 렌드링 마다 실행
// 2. useEffect(()=>{
//      // 컴포넌트가 마운트 될때  
//      return() => {  //cleanup함수
//         // 컴포넌트가 언마운트 될 때
//      }
//  }, [])  //마운트 될때 한번 실행
// 3. useEffect(()=> {
//       // value가 바뀔 때마다 실행(2)
//       return() => { //cleanup함수
//          // value가 바뀌기 직전에 실행(1)  
//       }
//  }, [value1, vaule2...]) //마운트 + 상태값(value)이 변경될때 마다 실행
// value값 a -> b 바뀌면
// 1. cleanup 함수 실행
// 2. useEffect내의 함수 실행

import { useEffect, useState } from 'react'
const UseEffectHook = () => {
  const [count, setCount] = useState(0);
  const [width, setWidth] = useState(0);
  const [height, setHeight] = useState(0);
  //1.렌드링마다 호출
  useEffect(() => {
    //console.log("렌드링마다 호출");
  })
  //2.마운트될때 한번 호출
  useEffect(()=>{
    console.log("마운트될 때 한번 호출")
    return () => {
      console.log("언마운트될 때 한번 호출")
    }
  }, [])

  const handleResize=()=>{
    setWidth(window.innerWidth);
    setHeight(window.innerHeight);
  }
  //
  useEffect(()=>{
    window.addEventListener("resize", handleResize)
    console.log("마운트될 때 한번 호출!!!")
    return () => {
      window.removeEventListener("resize", handleResize);
      console.log("언마운트될 때 한번 호출!!!")
    }
  }, [])

  useEffect(() => {
    //console.log("width, height가 바뀔 때마다 실행")
    return () => {
      //console.log("width, height가 바뀌기 직전에 실행")
    }
  }, [width, height]);


  const increment = () => {
    setCount(c=>c+1)
  }
  return (
    <div>
      <p>Count: {count}</p>
      <button className="btn btn-primary" onClick={increment}>증가</button>
      <br/>
      <p>window width: {width}px</p>
      <p>window height: {height}px</p>
    </div>
  )
}

export default UseEffectHook
