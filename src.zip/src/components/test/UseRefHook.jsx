import React from 'react'
import { useRef } from 'react'

const UseRefHook = () => {
  const inputRef1 = useRef(null);
  const inputRef2 = useRef(null);
  const handeClick = () => {
    console.log(inputRef1);
    inputRef1.current.focus();
    inputRef1.current.value="1234";
    inputRef1.current.style.backgroundColor = "yellow";
    inputRef2.current.style.backgroundColor = "";
  }
  const handeClick2 = () => {
    console.log(inputRef2);
    inputRef2.current.focus();
    inputRef2.current.value="1234";
    inputRef1.current.style.backgroundColor = "";
    inputRef2.current.style.backgroundColor = "yellow";
  }
  return (
    <div>
      <input ref={inputRef1} />
      <button className='btn btn-secondary' onClick={handeClick}>클릭</button>
      <input ref={inputRef2} />
      <button className='btn btn-secondary' onClick={handeClick2}>클릭</button>
    </div>
  )
}

export default UseRefHook
