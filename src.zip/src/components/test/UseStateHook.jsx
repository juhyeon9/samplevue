import {useState} from 'react'

// 상태 변수를 선언
// 초기상태를 가져와서 현재 상태와 이를 업데이트 할 수 
// 있는 상태 설정함수.  한 쌍의 값을 반환한다.
// 렌더링트리거: 초기렌드링, 상태가 업데이트될때
const UseStateHook = () => {
  let [count, setCount] = useState(0)
  const decrement = () => {
    //count = count -1;
    //setCount(c-1)
    //setCount(c-1)
    setCount(prvCount => prvCount - 1);
    setCount(prvCount => prvCount - 1);
  }

  const increment = () => {
    setCount(prvCount => prvCount + 1);
    setCount(prvCount => prvCount + 1);
  }
  return (
    <div>
      <button className="btn btn-primary" onClick={decrement}>감소</button>
      <p>{count}</p>
      <button className="btn btn-primary" onClick={increment}>증가</button>
      
    </div>
  )
}

export default UseStateHook
