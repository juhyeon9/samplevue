import React from 'react'
import { useId } from 'react'

const UserIdHook = () => {
  const id = useId()
  const id2 = useId()
  console.log('id:::' + id, id2);
  return (
    <div>
      <label htmlFor={id}>Do you like React?</label>
      <input id={id} type="checkbox" name="react" />
      <br/>
      <label htmlFor={id+ '-firstName'}>First Name</label>
      <input id={id+ '-firstName'} type="text"></input>
      
    </div>
  )
}

export default UserIdHook
