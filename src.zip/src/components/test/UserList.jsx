import React from 'react'
import { useEffect } from 'react'

const UserList = ({users, onRemove, onToggle}) => {

  const User = ({user, onRemove, onToggle}) => {
    useEffect(() => {
      console.log('컴포넌트가 화면에 나타남')
      return () => {
        console.log('컴포넌트가 화면에서 사라짐')
      }
    }, [user])
    return (
      <div>
        <b
          style={{cursor: 'pointer', color:user.active?'green':'black'}}
          onClick={()=>onToggle(user.id)}
        >{user.username}</b><span>({user.email})</span>
        <button className="btn btn-danger btn-sm" onClick={()=>onRemove(user.id)}>삭제</button>
      </div>
    )
  }

  return (
    <div>
      {
        users.map((user, index) => <User user={user} onRemove={onRemove} onToggle={onToggle}/>)
      }
    </div>
  )
}

export default React.memo(UserList)
