import React from 'react'
import { getImageUrl } from '../common/commonFunction'
//props
// 상위 Component에서 하위 Component로 객체, 배열 및 함수를 포함한
// 모든 Javascript 값(string, number, object, array, function..)을 전달할 수 있다
const Avatar = ({person, size}) => {
  return (
    <section>
      <h2>{person.name}</h2>
      <img 
        className='avatar'
        src={getImageUrl(person,'s')}
        alt={person.name}
        width={size}
        height={size}
      />
    </section>
  )
}

export default Avatar
