import React from 'react'

//컴포넌트는 순수해야된다.
// 즉 호출시 동일한 결과를 리턴해야된다.
// 함수 밖에서 변수 선언은 안하는게 좋음
//let count = 0
const Cup = () => {
  let count = 0
  count = count + 1
  return (
    <div>
      <h4>손님용 컵 #{count}</h4>
    </div>
  )
}

export default Cup
