import React, { Component } from 'react'

class CounterClass extends Component {
  constructor(props) {
    super(props);
    this.state = {
      number: 0
    }
  }

  componentDidMount() {
    console.log('componentDidMount[class]')
  }

  componentDidUpdate() {
    console.log('componentDidUpdate[class]')
  }

  componentWillUnmount() {
    console.log('componentWillUnmount[class]')
  }

  increment = () => {
    this.setState({
      number: this.state.number + 1
    })
  }

  decrement = () => {
    this.setState({
      number: this.state.number - 1
    })
  }

  render() {
    return (
      <div>
        <h1>Class Counter</h1>
        <div>Value: {this.state.number}</div>
        <button className="btn btn-primary" onClick={this.increment}>증가</button>
        <button className="btn btn-primary" onClick={this.decrement}>감소</button>
      </div>
    )
  }

}

export default CounterClass
