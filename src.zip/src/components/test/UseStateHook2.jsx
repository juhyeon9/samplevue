import React, {useState} from 'react'

// 상태 변수를 선언
// 초기상태를 가져와서 현재 상태와 이를 업데이트 할 수 
// 있는 상태 설정함수.  한 쌍의 값을 반환한다.
// 렌더링트리거: 초기렌드링, 상태가 업데이트될때
const UseStateHook2 = () => {
  const [name, setName] = useState("손님");
  const [age, setAge] = useState(1);
  const [isEmployed, setIsEmployed] = useState(false);

  //이름변경
  const updateName = () => {
    setName("메시");
  }
  //나이변경
  const updateAge = () => {
    setAge(preAge => preAge +1);
  }

  //직원여부토글
  const toggleIsEmployed = () => {
    setIsEmployed(!isEmployed);
  }
  return (
    <div>
      <p>이름: {name}</p>
      <button className="btn btn-info" onClick={updateName}>이름변경</button>
      <p>나이: {age}</p>
      <button className="btn btn-info" onClick={updateAge}>나이변경</button>
      <p>직원여부:{isEmployed? 'Yes':'No'}</p>
      <button className="btn btn-info" onClick={toggleIsEmployed}>직원여부토글</button>
    </div>
  )
}

export default UseStateHook2
