import React from 'react'
import CounterContainer from './CounterContainer'
import { Provider } from 'react-redux';
import { legacy_createStore as createStore } from 'redux';
import rootReducer from '../../reducer/modules';

const store = createStore(rootReducer)

const ReduxTest = () => {
  return (
    <div>
      <Provider store={store}>
      <CounterContainer />
      </Provider>
    </div>
  )
}

export default ReduxTest
