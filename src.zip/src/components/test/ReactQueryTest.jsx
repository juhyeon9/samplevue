import React from 'react'

//React-Query:React Application에서 서버 상태(data)를 불러오고(fetching)
//캐싱하며(Caching) 지속적으로 동기화하고 업데이트하는 작업을 도와주는 라이브러리임
//1. 캐싱(Caching)
//   -반복적인 비동기 데이터 호출을 방지
//   -불필요한 API콜을 줄여 서버에 부하를 줄이는 효과
//2. 새로운 정보를 보여 줄수 있는 옵션
//   1)Remount: 컴포넌트 또는 페이지를 다시 mount시  refetchOnmount옵션을 사용:default(true)
//   2)Window refocus: 윈도우창을 다시 focus시 refetchOnWindowFocus옵션을 사용:default(true)
//   3)Network reconnect:네트워크가 다시연결되면 refetchOnWindowReconnect옵션을 사용:default(true)
//3. 상태관리라이버러리(Redux, Recoil,mobX) - Client 데이터관리
//    React-Query - Server데이터관리, ContextAPI 기반으로 동작
// npm i @tanstack/react-query
// const fetchUser= async () => await axios.get('/api/user).then(res=>res.data)
// const {data, isLoading, error..} = useQuery(['fetchUser'], fetchUser)

import {QueryClient, QueryClientProvider} from '@tanstack/react-query'
import UseQueryTest from '../reactquery/UseQueryTest';
import UseMutationTest from '../reactquery/UseMutationTest';

const queryClient = new QueryClient({refetchOnWindowFocus:false,refetchOnmount:true});
const ReactQueryTest = () => {
  return (
    <QueryClientProvider client={queryClient}>
    <div>
      <UseQueryTest />
      <br />
      <UseMutationTest />
      
    </div>
    </QueryClientProvider>
  )
}

export default ReactQueryTest
