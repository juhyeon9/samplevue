import React from 'react'

const Header = () => {
  return (
    <div>
      <header>
        <h1>Happy Job 홈페이지</h1>
        <nav>
          <ul>
            <li><a href="#!">홈</a></li>
            <li><a href="#!">소개</a></li>
            <li><a href="#!">서비스</a></li>
            <li><a href="#!">연락처</a></li>
          </ul>
        </nav>
      </header>
    </div>
  )
}

export default Header
