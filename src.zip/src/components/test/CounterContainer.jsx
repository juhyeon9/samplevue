import React from 'react'
import { useSelector, useDispatch } from 'react-redux'
import Counter from '../redux/Counter'
import { increase, decrease, setDiff } from '../../reducer/modules/counter'

const CounterContainer = () => {

  //useSelector는 리덕스 스토어의 상태를 조회하는 Hook임
  const { number, diff } = useSelector(state => ({
    number: state.counter.number,
    diff: state.counter.diff
  }))

  //useDispatch는 리덕스의 스토어의 dispatch를 함수에서 사용 할 수 있게 
  // 해주는 Hook 임
  const dispatch = useDispatch();
  const onIncrement = () => dispatch(increase())
  const onDecrement = () => dispatch(decrease())
  const onSetDiff = (diff) => dispatch(setDiff(diff))

  return (
    <Counter
      number={number}
      diff={diff}
      onIncrement={onIncrement}
      onDecrement={onDecrement}
      onSetDiff={onSetDiff}
    />
  )
}

export default CounterContainer
