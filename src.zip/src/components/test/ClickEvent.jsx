import React from 'react'
import { AlertButton, PlayButton, SmashButton, Toolbar,ChangeButtonColor } from '../common/commonFunction'

const ClickEvent = () => {
  const handleClick= () => {
    alert("클릭하셔군요!!")
  }

  const handleSmashClick = () => {
    alert('스매시를 클릭 하셨군요!!')
  }
  return (
    <div>
      <button className="btn btn-primary" onClick={handleClick}>클릭</button>
      {/*렌드링 될 때마다 실행 됨
      <button className="btn btn-primary" onClick={handleClick()}>잘못된 클릭</button>
      */}
      {/*
      <button className="btn btn-success" onClick={(alert('잘못 호출')}>잘못 호출</button>
      */}
      {/**핸들러 인라인으로 정의 하려면 익명함수로 래핑 */}
      <button className="btn btn-success" onClick={() => alert('정상 호출')}>정상 호출</button>
      {/**component props전달, Children전달 */}
      <AlertButton message="놀자">
        영화보면서 놀자
      </AlertButton>
      <br/>
      {/**component props전달, 자식 Component 이벤트 호출 */}
      <PlayButton playName="농구"/>
      {/**component props전달, 부모 Component 이벤트 호출 */}
      <SmashButton onSmash={handleSmashClick}>스매시</SmashButton>

      {/**Event propagation */}
      <Toolbar />
      {/**실습:버튼 클릭시 버튼 색 변경하기 */}
      <ChangeButtonColor />
    </div>
  )
}

export default ClickEvent
