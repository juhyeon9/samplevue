import React from 'react'
import { PropTypes } from 'prop-types'

//props
// 상위 Component에서 하위 Component로 객체, 배열 및 함수를 포함한
// 모든 Javascript 값(string, number, object, array, function..)을 전달할 수 있다
const Student = (props) => {
  return (
    <div>
      <p>이름: {props.name}</p>
      <p>나이: {props.age}</p>
      <p>학생?: {props.isStudent? 'Yes' : 'No'}</p>
    </div>
  )
}

Student.propTypes = {
  name: PropTypes.string,
  age: PropTypes.number,
  isStudent: PropTypes.bool,
}

Student.defaultProps = {
  name: "Guest",
  age: 0,
  isStudent: false,
}

export default Student
