import React from 'react'
import { useInput } from '../common/commonFunction'

const displayMessage = (message) => {
  alert(message);
}
const displayMessage2 = (message) => {
  alert(message);
}

const CustomHook = () => {
  const [inputValue, handleChange, handleSubmit] = useInput("hi", displayMessage)
  const [inputValue2, handleChange2, handleSubmit2] = useInput("hi", displayMessage2)
  return (
    <div>
      <h1>useInput</h1>
      <input value={inputValue} onChange={handleChange} />
      <button className="btn btn-primary" onClick={handleSubmit}>확인</button>
      <input value={inputValue2} onChange={handleChange2} />
      <button className="btn btn-primary" onClick={handleSubmit2}>확인</button>
    </div>
  )
}

export default CustomHook
