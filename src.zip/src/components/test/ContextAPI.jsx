import React, { useContext } from 'react'
import { createContext } from 'react'
import './style.css'
const themeDefault = {border:'10px solid green'}
const themeContext = createContext(themeDefault)

const ContextAPI = () => {

  const theme= useContext(themeContext)
  return (
    <div className="root" style={theme}>
      <h1>hello world!</h1>
      <Sub1 />
    </div>
  )
}

const Sub1= () => {
  const theme= useContext(themeContext)
  return(
    <themeContext.Provider value={{border: '10px solid red'}}>
    <div style={theme}>
      <h1>Sub1</h1>
      <Sub2 />
    </div>
    </themeContext.Provider>
  )
}

const Sub2= () => {
  const theme= useContext(themeContext)
  return(
    <div style={theme}>
      <h1>Sub2</h1>
      <Sub3 />
    </div>
  )
}

const Sub3= () => {
  const theme= useContext(themeContext)
  return(
    <div style={theme}>
      <h1>Sub3</h1>
    </div>
  )
}


export default ContextAPI
