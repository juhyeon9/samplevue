import React, {useState} from 'react'

// 상태 변수를 선언
// 초기상태를 가져와서 현재 상태와 이를 업데이트 할 수 
// 있는 상태 설정함수.  한 쌍의 값을 반환한다.
// 렌더링트리거: 초기렌드링, 상태가 업데이트될때
const UseStateHook3 = () => {
  const [name, setName] = useState("")
  const [quantity, setQuantity] = useState(0)
  const [comment, setComment] = useState("")

  const [payment, setPayment] = useState("Visa")
  const [shipping, setShipping] = useState("")
  const [color, setColor] = useState("")

  const handleQuantityChange = (e) => {
    setQuantity(e.target.value)
  }
  return (
    <div>
      <input value={name} onChange={(e) => setName(e.target.value)}/>
      <p>이름: {name}</p>
      <input value={quantity} type="number" onChange={handleQuantityChange} />
      <p>수량: {quantity}</p>
      <textarea value={comment} onChange={e => setComment(e.target.value)} />
      <p>설명: {comment}</p>
      <select onChange={e=>setPayment(e.target.value)}>
        <option value="">select an option</option>
        <option value="Visa" selected>Visa</option>
        <option value="Mastercard">Master Card</option>
        <option value="Giftcard">Gift Card</option>
      </select>
      <p>선택: {payment}</p>
      <label>
        직접수령
        <input type="radio" value="Pick Up"
          onChange={e=>setShipping(e.target.value)}
          checked={shipping==="Pick Up"}
        />
      </label>
      <label>
        배송
        <input type="radio" value="Delivery"
          onChange={e=>setShipping(e.target.value)}
          checked={shipping==="Delivery"}
        />
      </label>
      <p>전달: {shipping}</p>

      <input type="color" value={color} onChange={e=>setColor(e.target.value)} />
    </div>
  )
}

export default UseStateHook3
