import React, { useState, useLayoutEffect } from 'react'
import logo_img from '../../assets/images/admin/login/logo_img.png'
import { useNavigate, Link } from 'react-router-dom'


const LeftMenu = () => {
  const [loginId, setLoginId] = useState('')
  const [loginNm, setLoginNm] = useState('')
  const [menuList, setMenuList] = useState([])
  const [subMenuStyle, setSubMenuStyle] = useState({ display: 'none', marginBottom: '0px' })
  
  //로드시
  useLayoutEffect(() => {
    console.log('leftmenu useLayoutEffect start!!')

    setLoginId(sessionStorage.getItem('loginId'))
    setLoginNm(sessionStorage.getItem('userNm'))
    setMenuList(JSON.parse(sessionStorage.getItem('usrMnuAtrt')))
  }, [])

  //대메뉴클릭시
  const menuClick = (e) => {
    e.preventDefault();
    console.log('menuClick start')
    const elem = e.currentTarget.parentElement?.nextElementSibling;
    if(elem.style.display === 'none') {
      elem.style.display = ''
    } else {
      elem.style.display = 'none'
    }
    //setSubMenuStyle({ display: 'none', marginBottom: '0px' })
    
  }

  //하위메뉴
  let i = -1
  const nodeList = () => {
    console.log('nodeList start')
    i++
    let nList = []
    let length = menuList[i].nodeList.length
    for (let j = 0; j < length; j++) {
      let url = '/dashboard' + menuList[i].nodeList[j].mnu_url
      if (!(url.indexOf('.do') === -1)) {
        url = url.slice(0, url.length - 3)
      }
      nList.push(
        <li key={j}>
          {<Link to={url}>- {menuList[i].nodeList[j].mnu_nm}</Link>}
          {
            // <a href={url}>
            //   - {menuList[i].nodeList[j].mnu_nm}
            // </a>
          }
        </li>,
      )
    }
    //MNU_URL
    //mnu_nm
    return nList
  }

  //로그아웃
  const navigate = useNavigate();
  const logoutProc = () => {
    if(window.confirm('로그아웃 하시겠습니까?')) {
      sessionStorage.setItem('loginId', '')
      sessionStorage.setItem('userNm', '')
      sessionStorage.setItem('usrMnuAtrt', '')
      navigate('/');
    }
  }
  return (
    <>
      <h3 className='hidden'>lnb 영역</h3>
      <div id='lnb_area'>
          <div id='header'>
            <a href="/dashboard/main" className='logo'>
              <img alt="logo" src={logo_img} />
            </a>
          </div>
      </div>
      <div className='login'>
        <span className='LoginName'>{loginId} {loginNm}</span>
        <div className='btn_loginArea'>
          <a href="#!" className='logout' onClick={logoutProc}>
            <span style={{ cursor: 'pointer' }}>LOGOUT</span>
          </a>
        </div>
      </div>
      <ul className='lnbMenu' style={{paddingLeft: '0px'}}>
        {menuList.map((list, index) => {
          let menuName = 'a' + index
          let subMenuName = 'dd' + index
          return (
            <li key={index}>
              <dl key={index}  style={{marginBottom: '0px'}}>
                <dt>
                  <a 
                    onClick={menuClick}
                    id={menuName}
                    href='#!'
                    className='lnbBtn menu005'
                  >
                    {list.mnu_nm}
                  </a>
                </dt>
                <dd style={subMenuStyle} id={subMenuName}>
                  {nodeList()}
                </dd>
              </dl>
            </li>
          )
        })}
      </ul>
    </>
  )
}
export default LeftMenu
