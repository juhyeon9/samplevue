import { useState } from "react"
//이미지 URL
export function getImageUrl (person, size) {
  return (
    'https://i.imgur.com/' + person.imageId + size + '.jpg'
  )
}


//if문사용
export function Item({name, isPacked}) {
  if(isPacked) {
    return(<li>{name} ✔</li>)
  } else {
    return(<li>{name}</li>)
  }
}

//삼항연산자
export function Item2({name, isPacked}) {
  return(<li>{isPacked? name + ' ✔' : name}</li>)
}

//&&, ||
export function Item3({name, isPacked}) {
  return (<li>{name} {isPacked && ' ✔'}</li>)
}

export function AlertButton({message, children}) {
  return(
    <button className="btn btn-secondary" onClick={()=>alert(message)}>
      {children}
    </button>
  )
}

export function PlayButton({playName}) {
  const handlePlayClick = () => {
    alert(`${playName} 하면서 놀자`)
  }
  return(
    <button className="btn btn-secondary" onClick={handlePlayClick}>
      "{playName}" 하면서 놀자
    </button>
  )
}

export function SmashButton({onSmash, children}) {
  return(
    <button className="btn btn-primary" onClick={onSmash}>
      {children}
    </button>
  )
}

//propagation test
export function Toolbar() {

  return(
    <div onClick={()=>{
      alert('상위 div 전달!');
    }}>
      <button className="btn btn-secondary" onClick={(e)=>{
        e.stopPropagation();
        alert('전달!');
      }}>
        상위까지 전달
      </button>
    </div>
  )
}

export function ChangeButtonColor() {
  const [color, setColor] = useState('yellow')
  const handleClick = (e) => {
    /*
    if(color==='yellow') {
      setColor('blue')
    } else {
      setColor('yellow')
    }
    */
     if(e.target.style.backgroundColor==='yellow') {
      e.target.style.backgroundColor = 'blue'
     } else {
      e.target.style.backgroundColor = 'yellow'
     }
  }
  return(
    <button style={{backgroundColor: color}} onClick={handleClick}>
      버튼 색변경
    </button>
  )
}

//custom hook
export function useInput(initalValue, submitAction) {
  const [inputValue, setInputValue] = useState(initalValue)

  const handleChange = (e) => {
    setInputValue(e.target.value);
  }

  const handleSubmit = () => {
    setInputValue("")
    submitAction(inputValue)
  }

  return [inputValue, handleChange, handleSubmit]

}
