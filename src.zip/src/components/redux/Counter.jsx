import React from 'react'

const Counter = ({number, diff, onIncrement, onDecrement, onSetDiff}) => {

  const onChange = e => {
    onSetDiff(parseInt(e.target.value,10));
  }
  return (
    <div>
      <h1>{number}</h1>
      <div>
        <input type="number" value={diff} min="1" onChange={onChange}/>
        <button className="btn btn-primary" onClick={onIncrement}>증가</button>
        <button className="btn btn-primary" onClick={onDecrement}>감소</button>
      </div>
    </div>
  )
}

export default Counter
