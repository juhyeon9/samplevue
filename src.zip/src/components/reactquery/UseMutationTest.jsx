import React from 'react'
import { useMutation } from '@tanstack/react-query'
import axios from 'axios'

//useMutation: PUT, UPDATE, DELETE와 같이 값을 변경할 때 사용하는 API
const UseMutationTest = () => {
  const updateNotice = async () => {
    const params = new URLSearchParams();
    params.append('noticeNo','60');
    params.append('noticeTitle', '공지사항60리코일테스트2');
    params.append('noticeContent', '공지사항60리코일테스트');
    params.append('noFile', 'noFile');
    const res = await axios.post('/api/system/noticeUpdate.do', params)
    return res;
  }

  const updateMuatation = useMutation({
    mutationFn: updateNotice,
    onSuccess: (data, variables, context) => {
      console.log(data, variables, context)
      console.log('수정요청성공!!')
    },
    onError:() => {
      console.error('에러발생')
    },
    onSettled: () => {
      console.error('결과에 관계 없이 무언가 실행됨')
    }

  })

  const {mutate} = () => updateMuatation();

  
  return (
    <div>
      <h3>useMutation</h3>
      <button className='btn btn-primary' onClick={()=>updateMuatation.mutate()}
       >공지사항수정</button>
    </div>
  )
}

export default UseMutationTest
