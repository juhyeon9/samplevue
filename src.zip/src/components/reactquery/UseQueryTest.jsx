import React from 'react'
import { useQuery } from '@tanstack/react-query'
import axios from 'axios'

//useQuery: Get
const UseQueryTest = () => {
  const fetchNotice = async() => {
    let params = new URLSearchParams();
    params.append('currentPage', '1');
    params.append('pageSize', '5');
    const res = await axios.post('/api/system/noticeList.do', params)
    return res.data;
  }

  const {data, status, error} = useQuery({
    queryKey:['fetchNotice'],
    queryFn:fetchNotice,
    gcTime: 5*60*100, //5분:fresh에서 stale상태로 변경되는 데 걸리는 시간
    staleTime: 1*50*1000,//1분: 데이터가 사용하지 않거나, inactive 상태일 때 
                         //캐싱 된 상태로 남아있는 시간
  })

  if(status==='pending') {
    return <span>Loading...</span>
  }

  if(status==='error') {
    return <span>Error:{error.message}</span>
  }

  if(status==='success') {
    console.log('조회성공');
  }

  return (
    <div>
      <h3>UseQuery</h3>
      <table className="col">
        <colgroup>
          <col width="15px" />
          <col width="80px" />
          <col />
          <col width="100px" />
          <col width="100px" />
          <col width="100px" />
        </colgroup>
        <thead>
          <tr>
            <th><input type='checkbox' name='noticeAllCheck'></input></th>
            <th scope='col'>공지번호</th>
            <th scope='col'>제목</th>
            <th scope='col'>등록일자</th>
            <th scope='col'>등록자ID</th>
            <th scope='col'>등록자명</th>
          </tr>
        </thead>
        <tbody>
          {data.noticeList.map((item, index) => {
            return(
              <tr key={index}>
                <td><input type='checkbox'/></td>
                <td>{item.notice_no}</td>
                <td>{item.notice_title}</td>
                <td>{item.notice_regdate}</td>
                <td>{item.login_id}</td>
                <td>{item.user_name}</td>
              </tr>
            )
          })}
        </tbody>
      </table>
    </div>
  )
}

export default UseQueryTest
