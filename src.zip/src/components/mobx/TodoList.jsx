import { observer } from 'mobx-react-lite';
import { todoStore } from './TodoStore';
import { useState } from 'react';

export const TodoListPage = observer(() => {
  const [inputValue, setInputValue] = useState('');
  const { todoData, addTodo, toggleTodo } = todoStore;

  return (
    <div>
      {todoData.map((todo) => {
        return (
          <div key={todo.id}>
            {todo.id} /{todo.content} /
            <input
              type="checkbox"
              checked={todo.checked}
              onChange={() => toggleTodo(todo.id)}
            />
          </div>
        );
      })}
      <hr></hr>
      <input
        type="text"
        value={inputValue}
        onChange={(e) => {
            setInputValue(e.target.value);
        }}
      />
      <button
        className="btn btn-primary"
        type="button"
        onClick={() => {
            if (inputValue) addTodo(inputValue);
        }}
      >
        할 일 추가하기
      </button>
    </div>
  );
});