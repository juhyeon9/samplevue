import React from 'react'
import { makeObservable, observable, action, computed, autorun } from 'mobx'

//https://velog.io/@bluecoolgod80/Mobx-%EC%82%AC%EC%9A%A9%EB%B2%95
class ObservableTodoStore {
  //todo 배열 상태
  todos = [];
  //남은 할일 숫자 상태
  pendingRequests = 0;

  // constructor에서 makeObservable 함수를 실행한다
  constructor() {
    makeObservable(this, {
      // 해당 함수의 두번째 인자로 주석을 넣어준다.
      todos: observable,
      pendingRequests: observable,
      completedTodosCount: computed,
      report: computed,
      addTodo: action,
    });
    //autorun:내용이 변경될 때마다 실행되어야 하는 하나의 함수를 인자로 받는다. 
    //observable 혹은 computed가 변화할 때마다 실행된다.
    autorun(() => console.log(this.report));
  }

  get completedTodosCount() {
    return this.todos.filter((todo) => todo.completed === true).length;
  }

  get report() {
    if (this.todos.length === 0) return "<할 일 없음>";
    const nextTodo = this.todos.find((todo) => todo.completed === false);
    return (
      `다음 할 일: "${nextTodo ? nextTodo.task : "<할 일 없음>"}".` +
      `진척도: ${this.completedTodosCount}/${this.todos.length}`
    );
  }

  addTodo(task) {
    this.todos.push({
      task: task,
      completed: false,
      assignee: null,
    });
  }
}

export default ObservableTodoStore
