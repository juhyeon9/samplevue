import React from 'react'
import { makeAutoObservable } from "mobx";

class TodoStore {
  	// 1
    todoData;
    currentId;

    constructor() {
      // 2
      makeAutoObservable(this, {}, { autoBind: true })
      // 3
      this.todoData = []
      this.currentId= 0
    }
    
    addTodo(content) {
      // 4
      this.todoData.push({id: this.currentId, content, checked:false})
      this.currentId++
    }

    toggleTodo(id) {
      const index = this.todoData.findIndex((v)=>v.id===id);
      if(id !== -1) {
        this.todoData[index].checked = !this.todoData[index].checked
      }
    }
}

// 5
export const todoStore = new TodoStore()
